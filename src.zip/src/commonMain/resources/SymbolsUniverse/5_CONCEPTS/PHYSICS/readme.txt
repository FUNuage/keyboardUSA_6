TIME and ENERGY may belong under Physics

Watch how DIGITAL WIZARD PATH DEVELOPES,   Seems like CONCEPTS/PHYSICS might be beyond simple Animation - 