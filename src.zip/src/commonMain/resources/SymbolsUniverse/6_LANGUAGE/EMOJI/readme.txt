nice variety of sets (50 and some more) for emojis at:  https://www.flaticon.com/packs/emotion-face?word=emoji

HOWEVER - NOT HANNES COMPATIBLE, USING POLYGON AND SO...   might use for inspiration?   Set of 10 - 20 more than enough to start with.

